# MovieXHub

A premium cinematic film and series discovery site built on the managed React/Vite + TypeScript + Tailwind frontend and Express server. The initialized project uses a deployment-ready Vite scaffold rather than Next.js.

## Development and build

Run `pnpm dev` from the project root for the managed Express/Vite preview on `PORT` (3000 by default). `pnpm check` runs TypeScript, `pnpm test` runs Vitest, `pnpm build` compiles client and server, `pnpm db:migrate` applies committed migrations, and `pnpm start` serves the production build.

## TMDb and authorized download links

Set `TMDB_API_KEY` as a protected server environment value. The Express `/api/tmdb/*` proxy permits only the movie and TV paths required by the UI; credentials never enter browser configuration. If TMDb is not configured or is unavailable, the discovery homepage shows curated fallback content. Homepage tabs separate Films, TV Shows, Web Series, and K-Dramas. TV titles use TMDb TV endpoints, Web Series are discovered by selected streaming networks, and K-Dramas filter on Korean original language and country. Search and genre discovery follow the chosen media format. Trailer metadata uses the corresponding movie or TV endpoint, and the modal embeds YouTube playback directly.

Movie details are available at `/movie/:id`. Authorized download metadata is stored by TMDb ID in the managed MySQL `movie_downloads` table with a 4K or 1080p quality label. The public details page displays a download action only when a mapping exists; it discloses the external provider and destination before the user chooses to continue. The confirmation modal provides three optional sponsor placements but does not block or delay downloads. MovieXHub is intended only for links the site operator is authorized to distribute.

The hidden `/admin-vault` route accepts an administrator password from the protected `ADMIN_VAULT_PASSWORD` project secret (minimum ten characters). Access is enforced server-side with rate limiting, a signed expiring HttpOnly Secure SameSite=None cookie, and CSRF protection. The form requires TMDb ID, an HTTPS URL, a quality label, and an affirmative rights confirmation. No credential is hardcoded or included in browser output. Homepage advertisement placements are inert, labeled layout containers in the discovery sidebar and between card rows; no ad scripts or tracking code are included.

## Source map

`client/src/pages/Home.tsx` owns format tabs and movie/TV discovery and search. `client/src/components/MovieCard.tsx` displays the normalized film and TV-series records; `client/src/components/TrailerModal.tsx` plays embedded YouTube trailers. `client/src/components/AdSpace.tsx` is the inert placeholder component. `client/src/pages/MovieDetails.tsx` loads TMDb movie metadata and its optional authorized link. `client/src/pages/AdminVault.tsx` provides the protected admin UI, and `client/src/components/DownloadDialog.tsx` displays the transparent destination and optional sponsor slots. `client/src/lib/tmdb.ts` contains typed same-origin TMDb movie and TV helpers. `client/src/lib/downloads.ts` contains same-origin authorized-link API types and calls. `server/downloads.ts` contains protected download/admin HTTP routes; `server/db.ts` performs Drizzle queries. The `movie_downloads` schema and additive migration are under `drizzle/`. `server/_core/index.ts` contains Express setup and the constrained TMDb proxy.

The managed server and managed database are enabled. The database is shared by development and published runtime; migrations are additive. `/api/health` is the configured health path. Browser routes are declared in `/manus-routes.json`.
