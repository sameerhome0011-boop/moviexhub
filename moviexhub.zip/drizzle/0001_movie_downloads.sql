CREATE TABLE `movie_downloads` (
	`tmdbId` int NOT NULL,
	`downloadUrl` varchar(2048) NOT NULL,
	`quality` enum('1080p','4K') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `movie_downloads_tmdbId` PRIMARY KEY(`tmdbId`)
);
