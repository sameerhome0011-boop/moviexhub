# MovieXHub implementation plan

## Approved scope
Continue the initialized React/Vite + TypeScript + Tailwind frontend and Express server. Preserve the existing TMDb proxy. Add detail routes at `/movie/:id`, database-backed authorized download-link metadata keyed by TMDb ID, and a mobile-friendly hidden `/admin-vault` route for maintaining official or otherwise authorized HTTPS download links. The server validates admin login using a protected `ADMIN_VAULT_PASSWORD` secret (minimum 10 characters, with five failed attempts per IP per 15 minutes); it issues an HttpOnly, Secure, SameSite=None, short-lived session cookie suitable for HTTPS Preview. No password is embedded in browser code. The detail page shows a quality-labeled download action only when a record exists. Selecting it opens a transparent confirmation modal with optional, labeled sponsor placements and no forced ad timer; the user can continue immediately. No unlicensed movie sources are to be cataloged.

For the final discovery refinements, keep trailer playback in `TrailerModal` using a standard `youtube.com/embed/{key}` iframe and remove any “Open/Watch on YouTube” action. Extend the typed TMDb client and the server's strict allowlist for `/trending/tv`, `/genre/tv/list`, `/search/tv`, `/discover/tv`, and `/tv/{id}/videos`, with only the needed query parameters. Normalize TMDb TV results into the existing reusable card/watchlist model (series name and first-air date), and offer distinct homepage tabs for Films, TV Shows, Web Series, and K-Dramas; K-Dramas use Korean origin/language discovery, while Web Series use a curated network filter. Reuse the same search, genre, trailer, and responsive layout behaviors where applicable. Add a reusable “Advertisement Space” placeholder for the discovery sidebar and insert full-width placeholders between result rows; placeholders are layout-only with no ad scripts or tracking code.

## Project structure
- `client/src/pages/Home.tsx`: homepage discovery and TMDb browsing.
- `client/src/pages/MovieDetails.tsx`: TMDb movie detail view and optional download action.
- `client/src/pages/AdminVault.tsx`: login and authorized-link management UI for `/admin-vault`.
- `client/src/components/DownloadDialog.tsx`: transparent, non-blocking download confirmation and clearly labeled optional placements.
- `client/src/components/TrailerModal.tsx`: embedded YouTube player, accessible cinematic trailer overlay.
- `client/src/components/AdSpace.tsx`: reusable, inert Advertisement Space placeholder.
- `client/src/lib/tmdb.ts`: typed same-origin TMDb helpers and fallback data.
- `client/src/lib/downloads.ts`: same-origin authorized-link and admin API helper types.
- `server/_core/index.ts`: constrained TMDb proxy plus download/admin HTTP routes.
- `server/downloads.ts`: database persistence/query operations.
- `drizzle/schema.ts` and `drizzle/0001_movie_downloads.sql`: additive persistent movie-link schema and migration.
- `client/src/App.tsx`: register `/movie/:id` and `/admin-vault` hidden from public navigation.
- `client/public/manus-routes.json`: keep all page routes declared.

## Design system
Reuse the existing Cinematic Obsidian system: charcoal #0B0B0A, warm gold #D4AF37, soft cream typography, spacious editorial layout, blurred translucent surfaces, Playfair Display + DM Sans, restrained motion, and responsive two-column mobile movie grids. Admin and details routes use the same visual system with touch-friendly form controls.

## Serving, security, and persistence
Use the managed Express server and managed MySQL database for durable download-link rows. The database is project-scoped and shared between development and published application; add one additive migration only and preserve unrelated rows. `TMDB_API_KEY` remains server-side. `ADMIN_VAULT_PASSWORD` is a protected environment secret used only for server-side login validation and cookie signing. Download-link writes require a valid signed, expiring HttpOnly/Secure/SameSite=None cookie; public readers receive only a link mapped to a valid TMDb movie ID. Validate positive integer IDs, quality values, URL length, and HTTPS URL format. All browser endpoints are relative. The app does not proxy custom URLs or force ad views/countdowns; external link navigation is clearly disclosed. Keep health endpoint `/api/health`.
