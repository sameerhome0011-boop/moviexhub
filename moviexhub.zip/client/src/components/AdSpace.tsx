type Props = { placement: "sidebar" | "interstitial"; className?: string };

export default function AdSpace({ placement, className = "" }: Props) {
  return <div
    className={`ad-space ad-space-${placement} ${className}`.trim()}
    role="complementary"
    aria-label="Advertisement Space"
    data-ad-slot={placement}
  >
    <span className="ad-space-label">Advertisement Space</span>
    <span className="ad-space-note">Reserved placement</span>
  </div>;
}
