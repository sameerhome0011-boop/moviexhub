import { motion } from "framer-motion";
import { Bookmark, Play, Star } from "lucide-react";
import { Link } from "wouter";
import { imageUrl, type Movie } from "@/lib/tmdb";

type Props = { movie: Movie; index?: number; saved?: boolean; onSave?: (movie: Movie) => void; onTrailer: (movie: Movie) => void };

export default function MovieCard({ movie, index = 0, saved = false, onSave, onTrailer }: Props) {
  const year = movie.release_date ? new Date(movie.release_date).getFullYear() : "—";
  const isTv = movie.media_type === "tv";
  const categoryLabel = movie.catalogLabel ?? (isTv ? "TV SERIES" : "FEATURE FILM");
  return (
    <motion.article
      className="movie-card group"
      initial={{ opacity: 0, y: 22 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay: Math.min(index * 0.045, 0.3), ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -7, scale: 1.012 }}
    >
      <div className="movie-tilt" onMouseMove={event => {
        const rect = event.currentTarget.getBoundingClientRect();
        const rx = ((event.clientY - rect.top) / rect.height - 0.5) * -5;
        const ry = ((event.clientX - rect.left) / rect.width - 0.5) * 6;
        event.currentTarget.style.setProperty("--tilt-x", `${rx}deg`);
        event.currentTarget.style.setProperty("--tilt-y", `${ry}deg`);
      }}
      onMouseLeave={event => {
        event.currentTarget.style.setProperty("--tilt-x", "0deg");
        event.currentTarget.style.setProperty("--tilt-y", "0deg");
      }}>
      <button className="poster-shell" onClick={() => onTrailer(movie)} aria-label={`Watch trailer for ${movie.title}`}>
        {movie.poster_path ? <img className="poster-image" src={imageUrl(movie.poster_path)} alt={`${movie.title} poster`} loading={index > 5 ? "lazy" : "eager"} /> : <div className="poster-placeholder"><span>MXH</span><small>NOIR COLLECTION</small></div>}
        <div className="poster-shade" />
        <span className="poster-index">{String(index + 1).padStart(2, "0")}</span>
        <span className="poster-rating"><Star size={12} fill="currentColor" /> {movie.vote_average ? movie.vote_average.toFixed(1) : "—"}</span>
        <span className="poster-play"><Play size={17} fill="currentColor" /></span>
        <span className="poster-caption">VIEW {isTv ? "SERIES" : "FILM"} <span>↗</span></span>
      </button>
      <div className="movie-card-info">
        <div className="movie-card-copy">
          <h3 title={movie.title}>{isTv ? movie.title : <Link href={`/movie/${movie.id}`}>{movie.title}</Link>}</h3>
          <p>{year}<span className="meta-dot">·</span> {categoryLabel}</p>
          {isTv ? <button className="movie-details-link card-trailer-link" onClick={() => onTrailer(movie)}>WATCH SERIES TRAILER ↗</button> : <Link className="movie-details-link" href={`/movie/${movie.id}`}>VIEW DETAILS ↗</Link>}
        </div>
        {onSave && <button className={`save-button ${saved ? "is-saved" : ""}`} aria-label={saved ? `Remove ${movie.title} from watchlist` : `Save ${movie.title}`} onClick={() => onSave(movie)}><Bookmark size={15} fill={saved ? "currentColor" : "none"} /></button>}
      </div>
      </div>
    </motion.article>
  );
}
