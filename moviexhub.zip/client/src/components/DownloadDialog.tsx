import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, BadgeCheck, ExternalLink, ShieldCheck, X } from "lucide-react";
import { useEffect, useRef } from "react";
import type { MovieDownload } from "@/lib/downloads";

type Props = { title: string; download: MovieDownload | null; onClose: () => void };

export default function DownloadDialog({ title, download, onClose }: Props) {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!download) return;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const priorOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const handleKey = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", handleKey);
    return () => { document.body.style.overflow = priorOverflow; window.removeEventListener("keydown", handleKey); previous?.focus(); };
  }, [download, onClose]);

  return <AnimatePresence>
    {download && <motion.div className="download-overlay" role="presentation" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <motion.section className="download-dialog" role="dialog" aria-modal="true" aria-labelledby="download-dialog-title" initial={{ opacity: 0, y: 20, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12, scale: .98 }}>
        <header className="download-dialog-head"><div className="vault-kicker"><ShieldCheck size={14} /> SECURE PARTNER HANDOFF</div><button ref={closeRef} className="close-modal" onClick={onClose} aria-label="Close download dialog"><X size={19} /></button></header>
        <div className="download-dialog-body"><span className="download-quality">{download.quality}</span><h2 id="download-dialog-title">Your link is ready.</h2><p className="download-film-title">{title}</p><p className="download-disclosure"><BadgeCheck size={15} /> You’re leaving MovieXHub for an administrator-supplied authorized provider. Review the provider and its terms before proceeding.</p>
          <div className="sponsor-heading"><span>SPONSOR PLACEMENTS</span><small>OPTIONAL · NOT REQUIRED TO CONTINUE</small></div>
          <div className="sponsor-slot-grid">{[1, 2, 3].map(slot => <div className="sponsor-slot" key={slot} aria-label={`Optional sponsor placement ${slot}`}><span>OPTIONAL SPONSOR PLACEMENT {String(slot).padStart(2, "0")}</span><small>No sponsor content configured</small></div>)}</div>
          <div className="download-dialog-actions"><button className="download-secondary" onClick={onClose}>CANCEL</button><a className="gold-button download-continue" href={download.downloadUrl} target="_blank" rel="noopener noreferrer"><ExternalLink size={15} /> CONTINUE TO PROVIDER <ArrowUpRight size={13} /></a></div>
          <p className="download-host">Destination: {new URL(download.downloadUrl).hostname}</p>
        </div>
      </motion.section>
    </motion.div>}
  </AnimatePresence>;
}
