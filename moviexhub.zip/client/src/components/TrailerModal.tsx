import { AnimatePresence, motion } from "framer-motion";
import { Clapperboard, Maximize2, X } from "lucide-react";
import { useEffect, useRef } from "react";
import { imageUrl, type Movie } from "@/lib/tmdb";

type Props = { movie: Movie | null; videoKey: string | null; loading: boolean; onClose: () => void };

export default function TrailerModal({ movie, videoKey, loading, onClose }: Props) {
  const closeButton = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!movie) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const prior = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.requestAnimationFrame(() => closeButton.current?.focus());
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") { onClose(); return; }
      if (event.key !== "Tab") return;
      const focusable = document.querySelectorAll<HTMLElement>(".trailer-panel button:not(:disabled), .trailer-panel a[href], .trailer-panel iframe");
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    window.addEventListener("keydown", keydown);
    return () => { document.body.style.overflow = prior; window.removeEventListener("keydown", keydown); previousFocus?.focus(); };
  }, [movie, onClose]);

  return <AnimatePresence>
    {movie && <motion.div className="trailer-backdrop" role="dialog" aria-modal="true" aria-label={`${movie.title} trailer`}
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <motion.div className="trailer-panel" initial={{ opacity: 0, scale: 0.96, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.98, y: 12 }} transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}>
        <div className="trailer-topbar"><div className="trailer-brand"><span className="mini-mark">X</span><span>SCREENING ROOM <i> / </i> <b>TRAILER</b></span></div><button ref={closeButton} className="close-modal" onClick={onClose} aria-label="Close trailer"><X size={20} /></button></div>
        <div className="video-stage" style={{ backgroundImage: movie.backdrop_path ? `linear-gradient(0deg, rgba(8,8,7,.5), rgba(8,8,7,.2)), url(${imageUrl(movie.backdrop_path, "w1280")})` : undefined }}>
          {loading ? <div className="video-message"><span className="loader-ring" /><p>PREPARING YOUR SCREENING</p></div> : videoKey ? <iframe src={`https://www.youtube.com/embed/${encodeURIComponent(videoKey)}?autoplay=1&mute=1&rel=0&modestbranding=1`} title={`${movie.title} official trailer`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen /> : <div className="video-message"><Clapperboard size={34} strokeWidth={1.2} /><p>NO TRAILER AVAILABLE</p><span>We couldn't find a trailer for this title just now.</span></div>}
        </div>
        <div className="trailer-controls"><div className="trailer-title-row"><div><span className="eyebrow">NOW SCREENING · {movie.release_date?.slice(0, 4) || (movie.media_type === "tv" ? "SERIES" : "FEATURE")}</span><h2>{movie.title}</h2></div></div>
          <div className="timeline-labels"><span><Clapperboard size={12} /> CINEMATIC PREVIEW</span><span>TRAILER</span></div><div className="timeline-track"><div className="timeline-progress" /><i /></div>
          <div className="trailer-bottom-row"><span>MovieXHub Screening Room</span><button className="expand-hint" onClick={() => document.querySelector<HTMLIFrameElement>(".video-stage iframe")?.requestFullscreen?.()}><Maximize2 size={14} /> FULL SCREEN</button></div>
        </div>
      </motion.div>
    </motion.div>}
  </AnimatePresence>;
}
