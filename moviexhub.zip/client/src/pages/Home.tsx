import { motion } from "framer-motion";
import { Bookmark, ChevronDown, ChevronRight, Clapperboard, Film, Flame, Home as HomeIcon, Menu, Radio, Search, Sparkles, Tv, X } from "lucide-react";
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import MovieCard from "@/components/MovieCard";
import TrailerModal from "@/components/TrailerModal";
import AdSpace from "@/components/AdSpace";
import { fallbackGenres, fallbackKdramas, fallbackMovies, fallbackTvGenres, fallbackTvShows, fallbackWebSeries, getByGenre, getGenres, getKdramas, getMovieVideos, getTrending, getTrendingTv, getTvByGenre, getTvGenres, getTvVideos, getWebSeries, imageUrl, pickTrailer, searchMovies, searchTv, type DiscoveryTab, type Genre, type Movie } from "@/lib/tmdb";

const dateLabel = new Intl.DateTimeFormat("en", { month: "long", year: "numeric" }).format(new Date());
const tabs: { id: DiscoveryTab; label: string; icon: typeof Film; heading: string; kicker: string }[] = [
  { id: "films", label: "FILMS", icon: Film, heading: "The latest, worth watching.", kicker: "YOUR NEXT GREAT FILM" },
  { id: "tv", label: "TV SHOWS", icon: Tv, heading: "Series to settle into.", kicker: "YOUR NEXT GREAT SERIES" },
  { id: "web", label: "WEB SERIES", icon: Radio, heading: "Stories made for streaming.", kicker: "THE STREAMING SELECTION" },
  { id: "kdrama", label: "K-DRAMAS", icon: Sparkles, heading: "Korean stories in focus.", kicker: "A K-DRAMA SPOTLIGHT" },
];

function fallbackFor(tab: DiscoveryTab) {
  if (tab === "tv") return fallbackTvShows;
  if (tab === "web") return fallbackWebSeries;
  if (tab === "kdrama") return fallbackKdramas;
  return fallbackMovies;
}

const sameMedia = (left: Movie, right: Movie) => left.id === right.id && (left.media_type ?? "movie") === (right.media_type ?? "movie");

export default function Home() {
  const [movies, setMovies] = useState<Movie[]>(fallbackMovies);
  const [genres, setGenres] = useState<Genre[]>(fallbackGenres);
  const [activeTab, setActiveTab] = useState<DiscoveryTab>("films");
  const [selectedGenre, setSelectedGenre] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);
  const [savedMovies, setSavedMovies] = useState<Movie[]>([]);
  const [savedOnly, setSavedOnly] = useState(false);
  const [modalMovie, setModalMovie] = useState<Movie | null>(null);
  const [trailerKey, setTrailerKey] = useState<string | null>(null);
  const [trailerLoading, setTrailerLoading] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const trailerRequest = useRef<AbortController | null>(null);
  const hasKey = Boolean(window.__MANUS_CONFIG__?.tmdbConfigured);
  const tabInfo = tabs.find(tab => tab.id === activeTab) ?? tabs[0];

  useEffect(() => {
    if (!hasKey) {
      setGenres(activeTab === "films" ? fallbackGenres : fallbackTvGenres);
      return;
    }
    const controller = new AbortController();
    const request = activeTab === "films" ? getGenres(controller.signal) : getTvGenres(controller.signal);
    request.then(result => { if (result.genres.length) setGenres(result.genres); })
      .catch(() => setGenres(activeTab === "films" ? fallbackGenres : fallbackTvGenres));
    return () => controller.abort();
  }, [activeTab, hasKey]);

  useEffect(() => {
    const timer = window.setTimeout(() => setActiveQuery(query.trim()), 320);
    return () => window.clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    if (!hasKey) {
      setLoading(false);
      setIsLive(false);
      setMovies(fallbackFor(activeTab));
      return;
    }
    const controller = new AbortController();
    setLoading(true);
    const request = activeQuery
      ? activeTab === "films" ? searchMovies(activeQuery, controller.signal) : searchTv(activeQuery, controller.signal)
      : selectedGenre !== null
        ? activeTab === "films" ? getByGenre(selectedGenre, controller.signal) : getTvByGenre(selectedGenre, controller.signal)
        : activeTab === "films" ? getTrending(controller.signal)
          : activeTab === "tv" ? getTrendingTv(controller.signal)
            : activeTab === "web" ? getWebSeries(controller.signal) : getKdramas(controller.signal);
    request.then(result => { setMovies(result.results); setIsLive(true); })
      .catch(error => {
        if (error.name !== "AbortError") { setIsLive(false); setMovies(fallbackFor(activeTab)); }
      })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [activeQuery, activeTab, hasKey, selectedGenre]);

  const shownMovies = useMemo(() => {
    if (savedOnly) return savedMovies;
    if (!isLive && activeQuery) return movies.filter(movie => movie.title.toLowerCase().includes(activeQuery.toLowerCase()));
    if (!isLive && selectedGenre !== null) return movies.filter(movie => movie.genre_ids.includes(selectedGenre));
    return movies;
  }, [activeQuery, isLive, movies, savedOnly, savedMovies, selectedGenre]);
  const featured = movies[0] ?? fallbackFor(activeTab)[0];
  const toggleSaved = (movie: Movie) => setSavedMovies(current => current.some(item => sameMedia(item, movie)) ? current.filter(item => !sameMedia(item, movie)) : [...current, movie]);
  const chooseTab = (tab: DiscoveryTab) => { setActiveTab(tab); setSavedOnly(false); setSelectedGenre(null); setQuery(""); setActiveQuery(""); };
  const showHome = () => { chooseTab("films"); document.getElementById("top")?.scrollIntoView({ behavior: "smooth" }); };
  const openSearch = () => { setSavedOnly(false); document.getElementById("discover")?.scrollIntoView({ behavior: "smooth" }); window.setTimeout(() => searchRef.current?.focus(), 100); };
  const showWatchlist = () => { setSavedOnly(true); setSelectedGenre(null); setQuery(""); setActiveQuery(""); document.getElementById("discover")?.scrollIntoView({ behavior: "smooth" }); };

  const openTrailer = useCallback(async (movie: Movie) => {
    trailerRequest.current?.abort();
    const controller = new AbortController();
    trailerRequest.current = controller;
    setModalMovie(movie); setTrailerKey(null); setTrailerLoading(true);
    try {
      const result = movie.media_type === "tv" ? await getTvVideos(movie.id, controller.signal) : await getMovieVideos(movie.id, controller.signal);
      if (!controller.signal.aborted) setTrailerKey(pickTrailer(result.results)?.key ?? null);
    } catch { if (!controller.signal.aborted) setTrailerKey(null); }
    finally { if (!controller.signal.aborted) setTrailerLoading(false); }
  }, []);
  const closeTrailer = useCallback(() => { trailerRequest.current?.abort(); trailerRequest.current = null; setTrailerLoading(false); setModalMovie(null); }, []);

  const scrollToMovies = () => document.getElementById("discover")?.scrollIntoView({ behavior: "smooth" });
  const resetGenre = () => { setSelectedGenre(null); setSavedOnly(false); setQuery(""); setActiveQuery(""); };
  const title = savedOnly ? "Your watchlist" : activeQuery ? "Search results" : selectedGenre !== null ? genres.find(item => item.id === selectedGenre)?.name ?? "Curated for you" : tabInfo.heading;
  const subtitle = savedOnly ? "A personal collection, saved for another night." : activeQuery ? `A few frames around “${activeQuery}”.` : activeTab === "films" ? "A considered collection of films making their mark." : activeTab === "kdrama" ? "Korean-language dramas, selected for your next episode." : activeTab === "web" ? "Series from the world's leading streaming platforms." : "Stories with room to unfold.";

  return <div className="site-shell" id="top">
    <header className="site-header">
      <a className="brand-lockup" href="#top" onClick={event => { event.preventDefault(); showHome(); }} aria-label="MovieXHub home"><span className="brand-symbol"><i /><i /><i /></span><span className="brand-name">MOVIE<span>X</span>HUB</span><span className="brand-edition">THE FILM JOURNAL</span></a>
      <nav className="desktop-nav"><a className="nav-active" href="#discover">DISCOVER</a><a href="#collections">COLLECTIONS</a><button onClick={showWatchlist}>MY WATCHLIST <span className="watch-count">{savedMovies.length.toString().padStart(2, "0")}</span></button></nav>
      <div className="header-right"><span className="header-date">{dateLabel.toUpperCase()}</span><button className="header-search" onClick={openSearch} aria-label="Search titles"><Search size={17} /></button><button className="menu-button" aria-label="Open search" onClick={openSearch}><Menu size={20} /></button></div>
    </header>

    <main>
      <section className="hero-section" aria-label="Featured title">
        <div className="hero-backdrop" style={{ backgroundImage: featured.backdrop_path ? `url(${imageUrl(featured.backdrop_path, "original")})` : undefined }} />
        <div className="hero-grain" />
        <div className="hero-content">
          <motion.div className="hero-kicker" initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: .7 }}><span className="gold-rule" /> THE WEEK'S MOST TALKED ABOUT</motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .75, delay: .08 }}>{featured.title.includes(":") ? <><span>{featured.title.split(":")[0]}</span><i>:</i><br /><em>{featured.title.split(":").slice(1).join(":").trim()}</em></> : <span>{featured.title}</span>}</motion.h1>
          <motion.p className="hero-description" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .3 }}>{featured.overview || "A world of stories, composed for the big screen. Discover your next unforgettable watch."}</motion.p>
          <motion.div className="hero-actions" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .38 }}><button className="gold-button" onClick={() => openTrailer(featured)}><span className="button-play"><Clapperboard size={15} /></span> WATCH THE TRAILER <ChevronRight size={15} /></button><button className="text-link" onClick={scrollToMovies}>EXPLORE THE SELECTION <ChevronDown size={13} /></button></motion.div>
          <div className="hero-meta"><span><b>01</b> / {String(movies.length || 8).padStart(2, "0")}</span><span className="hero-meta-sep" /><span>EDITOR'S SPOTLIGHT</span><span className="hero-live"><i /> {isLive ? "LIVE FROM TMDB" : "CURATED SELECTION"}</span></div>
        </div>
        <div className="hero-side-note"><span>FRAME 001</span><i /></div><div className="hero-scroll" onClick={scrollToMovies}><span>SCROLL TO DISCOVER</span><div className="scroll-line" /></div>
      </section>

      <section className="marquee-strip" aria-label="MovieXHub editorial note"><span>IN GOOD COMPANY</span><i /> <span>THE STORIES THAT STAY WITH YOU</span><i /> <span>FILM, WITH INTENTION</span><i /> <span>EST. MMXXIV</span></section>

      <section className="discovery-section" id="discover">
        <div className="section-heading"><div><span className="eyebrow"><Flame size={13} /> {savedOnly ? "A PERSONAL COLLECTION" : activeQuery ? "A LITTLE CURIOSITY" : tabInfo.kicker}</span><h2>{title}</h2><p>{subtitle}</p></div>
          <div className="search-wrap"><Search size={16} /><input ref={searchRef} aria-label="Search films and series" placeholder="Find a film, a series..." value={query} onChange={event => { setQuery(event.target.value); setSavedOnly(false); }} /><kbd>↵</kbd>{query && <button className="clear-search" onClick={() => setQuery("")} aria-label="Clear search"><X size={13} /></button>}</div>
        </div>

        <div className="media-tabs" role="tablist" aria-label="Browse by format">
          {tabs.map(tab => { const Icon = tab.icon; return <button key={tab.id} role="tab" aria-selected={activeTab === tab.id} className={`media-tab ${activeTab === tab.id && !savedOnly ? "selected" : ""}`} onClick={() => chooseTab(tab.id)}><Icon size={14} />{tab.label}</button>; })}
        </div>
        <div className="filter-row"><div className="genre-filters"><button className={`genre-chip ${selectedGenre === null && !savedOnly ? "selected" : ""}`} onClick={resetGenre}>ALL {activeTab === "films" ? "FILMS" : "SERIES"} <span>✳</span></button>{genres.slice(0, 7).map(genre => <button key={genre.id} className={`genre-chip ${selectedGenre === genre.id ? "selected" : ""}`} onClick={() => { setSavedOnly(false); setQuery(""); setActiveQuery(""); setSelectedGenre(genre.id); }}>{genre.name.toUpperCase()}</button>)}</div><span className="result-count">{loading ? "CURATING..." : `${String(shownMovies.length).padStart(2, "0")} TITLES`}</span></div>

        <div className="discovery-layout">
          <div className="discovery-results">
            <div className="movie-grid" aria-live="polite">
              {loading && shownMovies.length === 0 ? <div className="loading-state"><span className="loader-ring" /> FINDING YOUR NEXT STORY</div> : shownMovies.map((movie, index) => <Fragment key={`${movie.media_type ?? "movie"}-${movie.id}`}>
                <MovieCard movie={movie} index={index} saved={savedMovies.some(item => sameMedia(item, movie))} onSave={toggleSaved} onTrailer={openTrailer} />
                {(index + 1) % 4 === 0 && index + 1 < shownMovies.length && <AdSpace placement="interstitial" className="ad-after-four" />}
                {(index + 1) % 6 === 0 && index + 1 < shownMovies.length && <AdSpace placement="interstitial" className="ad-after-six" />}
              </Fragment>)}
            </div>
            {!loading && shownMovies.length === 0 && <div className="empty-state"><span className="empty-mark">X</span><h3>{savedOnly ? "Your list is a blank reel." : "No stories found in this frame."}</h3><p>{savedOnly ? "Save a title with the bookmark and it will be waiting here." : hasKey ? "Try another title or choose a different category." : "The live TMDb feed can be configured when ready."}</p><button className="small-gold-button" onClick={() => { if (savedOnly) resetGenre(); else { setQuery(""); resetGenre(); } }}>{savedOnly ? "BACK TO DISCOVER" : "CLEAR FILTERS"}</button></div>}
            <div className="grid-footnote"><span><Sparkles size={13} /> HANDPICKED FOR THE CURIOUS</span><span>{isLive ? "POWERED BY TMDB" : "A CURATED PREVIEW"}<i className={isLive ? "live-dot" : ""} /></span></div>
          </div>
          <aside className="discovery-sidebar" aria-label="Advertisement sidebar"><AdSpace placement="sidebar" /></aside>
        </div>
      </section>

      <section className="editorial-section" id="collections"><div className="editorial-mark">X</div><div className="editorial-copy"><span className="eyebrow">A NOTE FROM THE EDITORS</span><h2>Great stories deserve<br /><em>your full attention.</em></h2><p>Less scrolling. More feeling. A little corner of the internet devoted to the stories that linger after the credits.</p><button className="text-link" onClick={scrollToMovies}>RETURN TO THE SELECTION <ChevronRight size={13} /></button></div><div className="editorial-index">VOL. 01 <span>·</span> NO. 07</div></section>
    </main>

    <footer className="site-footer"><a className="footer-brand" href="#top" onClick={event => { event.preventDefault(); showHome(); }}>MOVIEXHUB<span>®</span></a><span>AN INDEPENDENT FILM DISCOVERY JOURNAL</span><span>© 2026 MOVIEXHUB</span></footer>

    <nav className="mobile-dock" aria-label="Mobile navigation"><button className={!savedOnly ? "dock-active" : ""} onClick={showHome}><HomeIcon size={19} /><span>HOME</span></button><button onClick={openSearch}><Search size={19} /><span>SEARCH</span></button><button onClick={() => { setSavedOnly(false); setSelectedGenre(null); scrollToMovies(); }}><Film size={19} /><span>EXPLORE</span></button><button className={savedOnly ? "dock-active" : ""} onClick={showWatchlist}><Bookmark size={19} /><span>SAVED{savedMovies.length > 0 ? ` · ${savedMovies.length}` : ""}</span></button></nav>
    <TrailerModal movie={modalMovie} videoKey={trailerKey} loading={trailerLoading} onClose={closeTrailer} />
  </div>;
}
