import { useEffect, useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, CheckCircle2, KeyRound, Link2, LogOut, ShieldCheck } from "lucide-react";
import { getAdminSession, loginAdmin, logoutAdmin, saveMovieDownload, type DownloadQuality } from "@/lib/downloads";

export default function AdminVault() {
  const [, setLocation] = useLocation();
  const [checking, setChecking] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [csrfToken, setCsrfToken] = useState("");
  const [password, setPassword] = useState("");
  const [tmdbId, setTmdbId] = useState("");
  const [downloadUrl, setDownloadUrl] = useState("");
  const [quality, setQuality] = useState<DownloadQuality>("1080p");
  const [rightsConfirmed, setRightsConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const robots = document.createElement("meta");
    robots.name = "robots";
    robots.content = "noindex, nofollow";
    document.head.appendChild(robots);
    return () => robots.remove();
  }, []);

  useEffect(() => {
    let alive = true;
    getAdminSession().then(session => {
      if (!alive) return;
      setAuthenticated(session.authenticated);
      setCsrfToken(session.csrfToken ?? "");
    }).catch(() => undefined).finally(() => { if (alive) setChecking(false); });
    return () => { alive = false; };
  }, []);

  const onLogin = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const session = await loginAdmin(password);
      setCsrfToken(session.csrfToken); setAuthenticated(true); setPassword("");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Unable to sign in."); }
    finally { setBusy(false); }
  };

  const onSave = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const id = Number(tmdbId);
      await saveMovieDownload({ tmdbId: id, downloadUrl: downloadUrl.trim(), quality, authorizationConfirmed: rightsConfirmed }, csrfToken);
      setNotice(`Authorized ${quality} link saved for TMDb movie ${id}.`);
      setTmdbId(""); setDownloadUrl(""); setRightsConfirmed(false);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Unable to save the link."); }
    finally { setBusy(false); }
  };

  const onLogout = async () => {
    try { if (csrfToken) await logoutAdmin(csrfToken); } finally { setAuthenticated(false); setCsrfToken(""); }
  };

  return <main className="vault-page">
    <header className="vault-header"><button className="vault-back" onClick={() => setLocation("/")}><ArrowLeft size={15} /> MOVIEXHUB</button><span className="vault-header-mark"><i /> PRIVATE ADMIN</span></header>
    <section className="vault-card">
      <div className="vault-icon"><ShieldCheck size={21} /></div><span className="eyebrow">MOVIEXHUB · ADMIN VAULT</span><h1>{authenticated ? "Authorized links." : "Private screening room."}</h1><p className="vault-intro">{authenticated ? "Map a TMDb film to an official or otherwise authorized download provider." : "Sign in to manage links for content you’re authorized to distribute."}</p>
      {checking ? <div className="vault-status">VERIFYING SECURE SESSION…</div> : authenticated ? <>
        <form className="vault-form" onSubmit={onSave}>
          <label>TMDB MOVIE ID<input inputMode="numeric" pattern="[1-9][0-9]*" required min="1" max="2000000000" value={tmdbId} onChange={event => setTmdbId(event.target.value)} placeholder="e.g. 603" /></label>
          <label>AUTHORIZED DOWNLOAD URL<input type="url" required maxLength={2048} pattern="https://.+" value={downloadUrl} onChange={event => setDownloadUrl(event.target.value)} placeholder="https://official-provider.example/..." /></label>
          <label>AVAILABLE QUALITY<select value={quality} onChange={event => setQuality(event.target.value as DownloadQuality)}><option value="1080p">1080p</option><option value="4K">4K</option></select></label>
          <label className="rights-check"><input type="checkbox" checked={rightsConfirmed} onChange={event => setRightsConfirmed(event.target.checked)} required /><span>I confirm I’m authorized to distribute this download and that the provider link complies with applicable rights and terms.</span></label>
          <button className="vault-submit" type="submit" disabled={busy || !csrfToken || !rightsConfirmed}><Link2 size={15} /> {busy ? "SAVING SECURELY…" : "SAVE AUTHORIZED LINK"}</button>
        </form>
        {notice && <p className="vault-notice"><CheckCircle2 size={15} /> {notice}</p>}
        {error && <p className="vault-error" role="alert">{error}</p>}
        <button className="vault-logout" onClick={onLogout}><LogOut size={14} /> SIGN OUT</button>
      </> : <>
        <form className="vault-form" onSubmit={onLogin}>
          <label>ADMIN PASSWORD<span className="vault-input-wrap"><KeyRound size={15} /><input type="password" autoComplete="current-password" required value={password} onChange={event => setPassword(event.target.value)} placeholder="Enter your private vault password" /></span></label>
          <button className="vault-submit" type="submit" disabled={busy}>{busy ? "VERIFYING…" : "UNLOCK VAULT"}</button>
        </form>
        {error && <p className="vault-error" role="alert">{error}</p>}
      </>}
      <p className="vault-footnote">Server-verified access · encrypted session cookie · authorized links only</p>
    </section>
  </main>;
}
