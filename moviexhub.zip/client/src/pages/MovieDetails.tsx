import { useEffect, useState } from "react";
import { Link, useLocation, useParams } from "wouter";
import { ArrowLeft, ArrowUpRight, Clapperboard, Download, ExternalLink, Film, Star } from "lucide-react";
import { motion } from "framer-motion";
import { getMovieDetails, imageUrl, type MovieDetails } from "@/lib/tmdb";
import { getMovieDownload, type MovieDownload } from "@/lib/downloads";
import DownloadDialog from "@/components/DownloadDialog";
import NotFound from "@/pages/NotFound";

export default function MovieDetailsPage() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const [, setLocation] = useLocation();
  const [movie, setMovie] = useState<MovieDetails | null>(null);
  const [download, setDownload] = useState<MovieDownload | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    if (!Number.isSafeInteger(id) || id < 1) { setFailed(true); setLoading(false); return; }
    const controller = new AbortController();
    setLoading(true); setFailed(false); setMovie(null); setDownload(null);
    getMovieDetails(id, controller.signal).then(result => {
      setMovie(result);
      return getMovieDownload(id).then(link => setDownload(link)).catch(() => setDownload(null));
    }).catch(error => { if (error.name !== "AbortError") setFailed(true); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [id]);

  if (failed) return <NotFound />;
  if (loading || !movie) return <main className="details-loading"><span className="loader-ring" /> CURATING FILM DETAILS…</main>;

  const backdrop = movie.backdrop_path ? imageUrl(movie.backdrop_path, "original") : imageUrl(movie.poster_path, "w1280");
  const year = movie.release_date?.slice(0, 4) || "—";
  const closeDialog = () => setDialogOpen(false);

  return <main className="details-page" style={{ "--details-backdrop": backdrop ? `url("${backdrop}")` : "none" } as React.CSSProperties}>
    <header className="details-header"><Link href="/" className="details-brand"><span className="brand-symbol"><i /><i /><i /></span> MOVIE<span>X</span>HUB</Link><button className="details-back" onClick={() => setLocation("/")}><ArrowLeft size={15} /> BACK TO DISCOVER</button></header>
    <section className="details-layout">
      <motion.div className="details-poster" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}><img src={imageUrl(movie.poster_path, "w780")} alt={`${movie.title} poster`} /><span className="details-poster-mark"><Film size={13} /> MOVIEXHUB FILM JOURNAL</span></motion.div>
      <motion.article className="details-copy" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: .08 }}>
        <span className="eyebrow"><Clapperboard size={14} /> FEATURE PRESENTATION · {year}</span><h1>{movie.title}</h1>{movie.tagline && <p className="details-tagline">“{movie.tagline}”</p>}
        <div className="details-meta"><span><Star size={15} fill="currentColor" /> {movie.vote_average.toFixed(1)} / 10</span>{movie.runtime ? <span>{movie.runtime} MIN</span> : null}<span>{movie.genres?.map(genre => genre.name).slice(0, 3).join(" · ")}</span></div>
        <p className="details-overview">{movie.overview || "A story waiting to be discovered."}</p>
        {download ? <div className="authorized-download-card"><div><span className="authorized-label"><Download size={14} /> AUTHORIZED DOWNLOAD AVAILABLE</span><h2>Available in <em>{download.quality}</em></h2><p>External provider link, supplied by MovieXHub administrators.</p></div><button className="gold-button details-download" onClick={() => setDialogOpen(true)}><Download size={16} /> DOWNLOAD · {download.quality} <ArrowUpRight size={14} /></button><small><ExternalLink size={12} /> You’ll review the provider before continuing.</small></div> : <div className="no-download-card"><span>NO AUTHORIZED DOWNLOAD LINK LISTED</span><p>Check official retailers and licensed streaming services in your region.</p></div>}
        <Link href="/" className="details-return"><ArrowLeft size={14} /> EXPLORE MORE FILMS</Link>
      </motion.article>
    </section>
    <DownloadDialog title={movie.title} download={dialogOpen ? download : null} onClose={closeDialog} />
  </main>;
}
