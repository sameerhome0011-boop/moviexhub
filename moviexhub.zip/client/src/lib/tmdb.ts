export type Movie = {
  id: number;
  title: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  release_date: string;
  genre_ids: number[];
  runtime?: number;
  media_type?: "movie" | "tv";
  catalogLabel?: string;
};

export type Genre = { id: number; name: string };
export type Trailer = { key: string; name: string; site: string; type: string; official?: boolean };
export type MovieDetails = Omit<Movie, "genre_ids"> & { genres: Genre[]; tagline: string };
export type DiscoveryTab = "films" | "tv" | "web" | "kdrama";

type TvShow = {
  id: number;
  name: string;
  overview?: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  first_air_date?: string;
  genre_ids?: number[];
};

type ListResponse<T> = { results: T[]; page?: number; total_pages?: number };
const API_ROOT = "/api/tmdb";

export const imageUrl = (path: string | null, size = "w500") =>
  path ? `https://image.tmdb.org/t/p/${size}${path}` : "";

async function tmdb<T>(path: string, params: Record<string, string> = {}, signal?: AbortSignal): Promise<T> {
  const query = new URLSearchParams(params).toString();
  const response = await fetch(`${API_ROOT}${path}${query ? `?${query}` : ""}`, { signal });
  if (!response.ok) throw new Error(`Movie data service returned ${response.status}`);
  return response.json() as Promise<T>;
}

function normalizeTv(show: TvShow, catalogLabel: string): Movie {
  return {
    id: show.id,
    title: show.name,
    overview: show.overview ?? "",
    poster_path: show.poster_path,
    backdrop_path: show.backdrop_path,
    vote_average: show.vote_average,
    release_date: show.first_air_date ?? "",
    genre_ids: show.genre_ids ?? [],
    media_type: "tv",
    catalogLabel,
  };
}

function mapTv(response: ListResponse<TvShow>, label: string): ListResponse<Movie> {
  return { ...response, results: response.results.map(show => normalizeTv(show, label)) };
}

export const getTrending = (signal?: AbortSignal) => tmdb<ListResponse<Movie>>("/trending/movie/week", {}, signal);
export const getGenres = (signal?: AbortSignal) => tmdb<{ genres: Genre[] }>("/genre/movie/list", {}, signal);
export const searchMovies = (query: string, signal?: AbortSignal) =>
  tmdb<ListResponse<Movie>>("/search/movie", { query, include_adult: "false", page: "1" }, signal);
export const getByGenre = (genreId: number, signal?: AbortSignal) =>
  tmdb<ListResponse<Movie>>("/discover/movie", { with_genres: String(genreId), sort_by: "popularity.desc", include_adult: "false", page: "1" }, signal);
export const getMovieVideos = (movieId: number, signal?: AbortSignal) =>
  tmdb<{ results: Trailer[] }>(`/movie/${movieId}/videos`, {}, signal);
export const getMovieDetails = (movieId: number, signal?: AbortSignal) =>
  tmdb<MovieDetails>(`/movie/${movieId}`, {}, signal);

export const fallbackTvGenres: Genre[] = [
  { id: 18, name: "Drama" }, { id: 10759, name: "Action & Adventure" }, { id: 35, name: "Comedy" },
  { id: 80, name: "Crime" }, { id: 9648, name: "Mystery" }, { id: 10765, name: "Sci-Fi & Fantasy" },
];

export const getTvGenres = (signal?: AbortSignal) => tmdb<{ genres: Genre[] }>("/genre/tv/list", {}, signal);
export const getTrendingTv = async (signal?: AbortSignal) =>
  mapTv(await tmdb<ListResponse<TvShow>>("/trending/tv/week", {}, signal), "TV SERIES");
export const searchTv = async (query: string, signal?: AbortSignal) =>
  mapTv(await tmdb<ListResponse<TvShow>>("/search/tv", { query, include_adult: "false", page: "1" }, signal), "TV SERIES");
export const getTvByGenre = async (genreId: number, signal?: AbortSignal) =>
  mapTv(await tmdb<ListResponse<TvShow>>("/discover/tv", { with_genres: String(genreId), sort_by: "popularity.desc", include_adult: "false", page: "1" }, signal), "TV SERIES");

// TMDb network IDs for major streaming services; the pipe separator means OR in discover filters.
const STREAMING_NETWORKS = "213|1024|453|2739|2552";
export const getWebSeries = async (signal?: AbortSignal) =>
  mapTv(await tmdb<ListResponse<TvShow>>("/discover/tv", { with_networks: STREAMING_NETWORKS, sort_by: "popularity.desc", include_adult: "false", page: "1" }, signal), "WEB SERIES");
export const getKdramas = async (signal?: AbortSignal) =>
  mapTv(await tmdb<ListResponse<TvShow>>("/discover/tv", { with_origin_country: "KR", with_original_language: "ko", sort_by: "popularity.desc", include_adult: "false", page: "1" }, signal), "K-DRAMA");
export const getTvVideos = (showId: number, signal?: AbortSignal) =>
  tmdb<{ results: Trailer[] }>(`/tv/${showId}/videos`, {}, signal);

export const pickTrailer = (trailers: Trailer[]) =>
  trailers.find(video => video.site === "YouTube" && video.type === "Trailer" && video.official)
  ?? trailers.find(video => video.site === "YouTube" && video.type === "Trailer")
  ?? trailers.find(video => video.site === "YouTube");

const tvFallback = (id: number, title: string, date: string, genre_ids: number[], catalogLabel: string): Movie => ({
  id, title, overview: "An acclaimed series selected for your next unhurried watch.", poster_path: null, backdrop_path: null,
  vote_average: 8.1, release_date: date, genre_ids, media_type: "tv", catalogLabel,
});

export const fallbackTvShows: Movie[] = [
  tvFallback(66732, "Stranger Things", "2016-07-15", [18, 10765, 9648], "TV SERIES"),
  tvFallback(95396, "Severance", "2022-02-18", [18, 9648, 10765], "TV SERIES"),
  tvFallback(76479, "The Boys", "2019-07-26", [10759, 18, 10765], "TV SERIES"),
  tvFallback(100088, "The Last of Us", "2023-01-15", [18, 10759], "TV SERIES"),
];
export const fallbackWebSeries: Movie[] = [
  tvFallback(66732, "Stranger Things", "2016-07-15", [18, 10765, 9648], "WEB SERIES"),
  tvFallback(95396, "Severance", "2022-02-18", [18, 9648, 10765], "WEB SERIES"),
  tvFallback(119051, "Wednesday", "2022-11-23", [35, 80, 9648], "WEB SERIES"),
  tvFallback(1399, "Game of Thrones", "2011-04-17", [18, 10765, 10759], "WEB SERIES"),
];
export const fallbackKdramas: Movie[] = [
  tvFallback(93405, "Squid Game", "2021-09-17", [18, 9648, 10759], "K-DRAMA"),
  tvFallback(110356, "All of Us Are Dead", "2022-01-28", [18, 10765, 10759], "K-DRAMA"),
  tvFallback(106379, "The Glory", "2022-12-30", [18], "K-DRAMA"),
  tvFallback(99966, "Extraordinary Attorney Woo", "2022-06-29", [18, 35], "K-DRAMA"),
];

export const fallbackMovies: Movie[] = [
  { id: 693134, title: "Dune: Part Two", overview: "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.", poster_path: "/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg", backdrop_path: "/xOMo8BRK7PfcJv9JCnx7s5hj0PX.jpg", vote_average: 8.2, release_date: "2024-02-27", genre_ids: [878, 12] },
  { id: 872585, title: "Oppenheimer", overview: "The story of J. Robert Oppenheimer and his role in the development of the atomic bomb.", poster_path: "/ptpr0kGAckfQkJeJIt8st5dglvd.jpg", backdrop_path: "/fm6KqXpk3M2HVveHwCrBSSBaO0V.jpg", vote_average: 8.1, release_date: "2023-07-19", genre_ids: [18, 36] },
  { id: 569094, title: "Spider-Man: Across the Spider-Verse", overview: "Miles Morales catapults across the multiverse, where he encounters a team of Spider-People charged with protecting its very existence.", poster_path: "/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg", backdrop_path: "/4HodYYKEIsGOdinkGi2Ucz6X9i0.jpg", vote_average: 8.4, release_date: "2023-05-31", genre_ids: [16, 28] },
  { id: 792307, title: "Poor Things", overview: "The incredible tale and fantastical evolution of Bella Baxter, a young woman brought back to life by Dr. Godwin Baxter.", poster_path: "/kCGlIMHnOm8JPXq3rXM6c5wMxcT.jpg", backdrop_path: "/5Eip60UDiPLASyKjmHPMruggTc4.jpg", vote_average: 7.8, release_date: "2023-12-07", genre_ids: [878, 10749] },
  { id: 603, title: "The Matrix", overview: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.", poster_path: "/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg", backdrop_path: "/7u3pxc0K1wx32IleAkLv78MKgrw.jpg", vote_average: 8.2, release_date: "1999-03-30", genre_ids: [28, 878] },
  { id: 157336, title: "Interstellar", overview: "A team of explorers travels beyond this galaxy to discover whether mankind has a future.", poster_path: "/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg", backdrop_path: "/xJHokMbljvjADYdit5fK5VQsXEG.jpg", vote_average: 8.4, release_date: "2014-11-05", genre_ids: [12, 18] },
  { id: 438631, title: "Dune", overview: "A gifted young man must travel to the most dangerous planet in the universe to ensure the future of his family and his people.", poster_path: "/d5NXSklXo0qyIYkgV94XAgMIckC.jpg", backdrop_path: "/iopYFB1b6Bh7FWZh3onQhph1sih.jpg", vote_average: 7.8, release_date: "2021-09-15", genre_ids: [878, 12] },
  { id: 324857, title: "Spider-Man: Into the Spider-Verse", overview: "Teen Miles Morales becomes the Spider-Man of his universe and must join with five spider-powered individuals from other dimensions.", poster_path: "/iiZZdoQBEYBv6id8su7ImL0oCbD.jpg", backdrop_path: "/7d6EY00g1c39SGZOoCJ5py9nNth.jpg", vote_average: 8.4, release_date: "2018-12-06", genre_ids: [16, 28] },
];

export const fallbackGenres: Genre[] = [
  { id: 878, name: "Science Fiction" }, { id: 18, name: "Drama" }, { id: 28, name: "Action" },
  { id: 53, name: "Thriller" }, { id: 16, name: "Animation" }, { id: 80, name: "Crime" }, { id: 12, name: "Adventure" },
];
