export type DownloadQuality = "1080p" | "4K";

export type MovieDownload = {
  tmdbId: number;
  downloadUrl: string;
  quality: DownloadQuality;
};

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, { credentials: "same-origin", cache: "no-store", ...init });
  const payload = await response.json().catch(() => ({})) as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || `Request failed (${response.status})`);
  return payload;
}

export const getMovieDownload = (tmdbId: number) =>
  request<MovieDownload | null>(`/api/download-links/${tmdbId}`);

export const getAdminSession = () =>
  request<{ authenticated: boolean; csrfToken?: string }>("/api/admin-vault/session");

export const loginAdmin = (password: string) =>
  request<{ authenticated: boolean; csrfToken: string }>("/api/admin-vault/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ password }),
  });

export const saveMovieDownload = (input: MovieDownload & { authorizationConfirmed: boolean }, csrfToken: string) =>
  request<{ saved: boolean; download: MovieDownload }>("/api/admin-vault/download-links", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Admin-CSRF": csrfToken },
    body: JSON.stringify(input),
  });

export const logoutAdmin = (csrfToken: string) =>
  request<{ loggedOut: boolean }>("/api/admin-vault/logout", {
    method: "POST",
    headers: { "X-Admin-CSRF": csrfToken },
  });
