import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { registerDownloadRoutes } from "../downloads";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.use("/admin-vault", (_req, res, next) => {
    res.set("X-Robots-Tag", "noindex, nofollow").set("Cache-Control", "no-store");
    next();
  });
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.get("/api/tmdb/*", async (req, res) => {
    const resourcePath = req.path.replace(/^\/api\/tmdb/, "");
    const allowedPath = /^\/(?:trending\/(?:movie|tv)\/week|genre\/(?:movie|tv)\/list|search\/(?:movie|tv)|discover\/(?:movie|tv)|(?:movie|tv)\/\d+(?:\/videos)?)$/.test(resourcePath);
    if (!allowedPath) return res.status(404).json({ error: "Movie data route not found" });

    const apiKey = process.env.TMDB_API_KEY;
    if (!apiKey) return res.status(503).json({ error: "Movie data service is not configured" });

    const allowedParams = new Set(["language", "query", "include_adult", "page", "with_genres", "sort_by", "with_networks", "with_origin_country", "with_original_language"]);
    const upstreamUrl = new URL(`https://api.themoviedb.org/3${resourcePath}`);
    for (const [name, rawValue] of Object.entries(req.query)) {
      if (!allowedParams.has(name) || typeof rawValue !== "string") {
        return res.status(400).json({ error: "Invalid movie data query" });
      }
      upstreamUrl.searchParams.set(name, rawValue);
    }
    upstreamUrl.searchParams.set("api_key", apiKey);
    upstreamUrl.searchParams.set("language", upstreamUrl.searchParams.get("language") || "en-US");

    try {
      const upstream = await fetch(upstreamUrl, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(15000) });
      const payload: unknown = await upstream.json();
      return res.status(upstream.status).set("Cache-Control", "public, max-age=300, stale-while-revalidate=300").json(payload);
    } catch {
      return res.status(502).json({ error: "Movie data service is temporarily unavailable" });
    }
  });
  registerDownloadRoutes(app);
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
