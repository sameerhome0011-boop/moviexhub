import { createHmac, createHash, timingSafeEqual } from "node:crypto";
import type { Express, Request, Response } from "express";
import { parse as parseCookie } from "cookie";
import { findMovieDownload, upsertMovieDownload } from "./db";
import type { DownloadQuality } from "../drizzle/schema";

const COOKIE_NAME = "moviexhub_admin_session";
const SESSION_SECONDS = 2 * 60 * 60;
const MIN_ADMIN_PASSWORD_LENGTH = 10;
const failedLogins = new Map<string, { attempts: number; resetAt: number }>();

type AdminRequest = Request & { adminSessionToken?: string };

function safeEqual(left: string, right: string) {
  const leftDigest = createHash("sha256").update(left).digest();
  const rightDigest = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftDigest, rightDigest);
}

function hmac(message: string, key: string) {
  return createHmac("sha256", key).update(message).digest("base64url");
}

function signSession(expiresAt: number, password: string) {
  const payload = String(expiresAt);
  return `${payload}.${hmac(`moviexhub-admin:${payload}`, password)}`;
}

function validSession(req: Request, password: string) {
  const token = parseCookie(req.headers.cookie ?? "")[COOKIE_NAME];
  if (!token) return null;
  const [expiresText, signature, extra] = token.split(".");
  const expiresAt = Number(expiresText);
  if (extra !== undefined || !Number.isSafeInteger(expiresAt) || expiresAt <= Date.now() || expiresAt > Date.now() + SESSION_SECONDS * 1000 + 60_000 || !signature) return null;
  const expected = hmac(`moviexhub-admin:${expiresText}`, password);
  return safeEqual(signature, expected) ? token : null;
}

function csrfForSession(token: string, password: string) {
  return hmac(`moviexhub-admin-csrf:${token}`, password);
}

function sessionCookie(value: string, maxAge: number) {
  return `${COOKIE_NAME}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=None`;
}

function readAdminPassword() {
  const password = process.env.ADMIN_VAULT_PASSWORD;
  return password && password.length >= MIN_ADMIN_PASSWORD_LENGTH ? password : null;
}

function requireAdmin(req: AdminRequest, res: Response, next: (error?: unknown) => void) {
  const password = readAdminPassword();
  const token = password ? validSession(req, password) : null;
  if (!password) return res.status(503).json({ error: "Admin vault is not configured securely." });
  if (!token) return res.status(401).json({ error: "Admin authentication required." });
  req.adminSessionToken = token;
  return next();
}

function validCsrf(req: AdminRequest, password: string) {
  const token = req.adminSessionToken;
  const supplied = req.get("X-Admin-CSRF");
  return Boolean(token && supplied && safeEqual(supplied, csrfForSession(token, password)));
}

function positiveMovieId(value: unknown): number | null {
  if (typeof value !== "string" || !/^[1-9]\d{0,9}$/.test(value)) return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed <= 2_000_000_000 ? parsed : null;
}

function validAuthorizedUrl(value: unknown): value is string {
  if (typeof value !== "string" || value.length > 2048) return false;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password && Boolean(url.hostname) && url.hostname.includes(".");
  } catch {
    return false;
  }
}

function loginAllowed(ip: string) {
  const now = Date.now();
  const current = failedLogins.get(ip);
  if (!current || current.resetAt <= now) {
    failedLogins.set(ip, { attempts: 0, resetAt: now + 15 * 60_000 });
    return true;
  }
  return current.attempts < 5;
}

function recordFailedLogin(ip: string) {
  const current = failedLogins.get(ip);
  if (current) current.attempts += 1;
}

export function registerDownloadRoutes(app: Express) {
  app.get("/api/download-links/:tmdbId", async (req, res) => {
    res.set("Cache-Control", "no-store");
    const tmdbId = positiveMovieId(req.params.tmdbId);
    if (!tmdbId) return res.status(400).json({ error: "Invalid TMDb movie ID." });
    try {
      const download = await findMovieDownload(tmdbId);
      if (!download) return res.json(null);
      return res.json({ tmdbId: download.tmdbId, downloadUrl: download.downloadUrl, quality: download.quality });
    } catch {
      return res.status(503).json({ error: "Download link service is temporarily unavailable." });
    }
  });

  app.get("/api/admin-vault/session", (req, res) => {
    res.set("Cache-Control", "no-store");
    const password = readAdminPassword();
    const token = password ? validSession(req, password) : null;
    if (!password || !token) return res.json({ authenticated: false });
    return res.json({ authenticated: true, csrfToken: csrfForSession(token, password) });
  });

  app.post("/api/admin-vault/login", (req, res) => {
    res.set("Cache-Control", "no-store");
    const password = readAdminPassword();
    if (!password) return res.status(503).json({ error: "Admin vault is not configured securely." });
    const ip = req.ip || "unknown";
    if (!loginAllowed(ip)) return res.status(429).json({ error: "Too many attempts. Try again later." });
    const supplied = req.body?.password;
    if (typeof supplied !== "string" || !safeEqual(supplied, password)) {
      recordFailedLogin(ip);
      return res.status(401).json({ error: "Incorrect password." });
    }
    failedLogins.delete(ip);
    const expiresAt = Date.now() + SESSION_SECONDS * 1000;
    const token = signSession(expiresAt, password);
    res.append("Set-Cookie", sessionCookie(token, SESSION_SECONDS));
    return res.json({ authenticated: true, csrfToken: csrfForSession(token, password) });
  });

  app.post("/api/admin-vault/logout", requireAdmin, (req: AdminRequest, res) => {
    res.set("Cache-Control", "no-store");
    const password = readAdminPassword();
    if (!password || !validCsrf(req, password)) return res.status(403).json({ error: "Invalid request token." });
    res.append("Set-Cookie", sessionCookie("", 0));
    return res.json({ loggedOut: true });
  });

  app.post("/api/admin-vault/download-links", requireAdmin, async (req: AdminRequest, res) => {
    res.set("Cache-Control", "no-store");
    const password = readAdminPassword();
    if (!password || !validCsrf(req, password)) return res.status(403).json({ error: "Invalid request token." });
    const tmdbId = Number(req.body?.tmdbId);
    const urlValue: unknown = typeof req.body?.downloadUrl === "string" ? req.body.downloadUrl.trim() : null;
    const quality: unknown = req.body?.quality;
    if (!Number.isSafeInteger(tmdbId) || tmdbId < 1 || tmdbId > 2_000_000_000) return res.status(400).json({ error: "Enter a valid positive TMDb movie ID." });
    if (!validAuthorizedUrl(urlValue)) return res.status(400).json({ error: "Enter a valid HTTPS download provider URL." });
    if (quality !== "1080p" && quality !== "4K") return res.status(400).json({ error: "Choose 1080p or 4K quality." });
    if (req.body?.authorizationConfirmed !== true) return res.status(400).json({ error: "Confirm you are authorized to distribute this download." });
    try {
      const download = await upsertMovieDownload({ tmdbId, downloadUrl: urlValue, quality: quality as DownloadQuality });
      return res.json({ saved: true, download: { tmdbId: download.tmdbId, downloadUrl: download.downloadUrl, quality: download.quality } });
    } catch {
      return res.status(503).json({ error: "Could not save the authorized download link." });
    }
  });
}
