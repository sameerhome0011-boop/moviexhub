import express from "express";
import type { Server } from "http";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

const { findMovieDownloadMock, upsertMovieDownloadMock } = vi.hoisted(() => ({
  findMovieDownloadMock: vi.fn(),
  upsertMovieDownloadMock: vi.fn(),
}));

vi.mock("./db", () => ({
  findMovieDownload: findMovieDownloadMock,
  upsertMovieDownload: upsertMovieDownloadMock,
}));

import { registerDownloadRoutes } from "./downloads";

const testPassword = "moviexhub-test-password-123";
let server: Server;
let baseUrl = "";

async function login() {
  const response = await fetch(`${baseUrl}/api/admin-vault/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ password: testPassword }),
  });
  const setCookie = response.headers.get("set-cookie") ?? "";
  const payload = await response.json() as { csrfToken: string };
  return { response, cookie: setCookie.split(";")[0], setCookie, csrfToken: payload.csrfToken };
}

async function adminPost(path: string, cookie: string, csrfToken: string, payload: unknown) {
  return fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: { Cookie: cookie, "X-Admin-CSRF": csrfToken, "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

beforeAll(async () => {
  const app = express();
  app.use(express.json());
  registerDownloadRoutes(app);
  server = await new Promise<Server>(resolve => {
    const instance = app.listen(0, "127.0.0.1", () => resolve(instance));
  });
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Test server did not bind a port.");
  baseUrl = `http://127.0.0.1:${address.port}`;
});

afterAll(async () => new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve())));
beforeEach(() => {
  vi.stubEnv("ADMIN_VAULT_PASSWORD", testPassword);
  findMovieDownloadMock.mockReset();
  upsertMovieDownloadMock.mockReset();
});
afterEach(() => vi.unstubAllEnvs());

describe("authorized movie downloads and admin vault", () => {
  it("issues an HttpOnly, Secure, SameSite=None expiring session and allows session validation", async () => {
    const result = await login();
    expect(result.response.status).toBe(200);
    expect(result.setCookie).toMatch(/HttpOnly/i);
    expect(result.setCookie).toMatch(/Secure/i);
    expect(result.setCookie).toMatch(/SameSite=None/i);
    expect(result.setCookie).toMatch(/Max-Age=7200/i);

    const session = await fetch(`${baseUrl}/api/admin-vault/session`, { headers: { Cookie: result.cookie } });
    expect(session.status).toBe(200);
    expect(await session.json()).toMatchObject({ authenticated: true });
  });

  it("rejects unauthorized writes, missing CSRF tokens, and invalid URL/rights payloads", async () => {
    const unauthenticated = await fetch(`${baseUrl}/api/admin-vault/download-links`, { method: "POST", body: "{}" });
    expect(unauthenticated.status).toBe(401);

    const auth = await login();
    expect((await adminPost("/api/admin-vault/download-links", auth.cookie, "", {})).status).toBe(403);
    expect((await adminPost("/api/admin-vault/download-links", auth.cookie, auth.csrfToken, {
      tmdbId: 603, downloadUrl: "javascript:alert(1)", quality: "1080p", authorizationConfirmed: true,
    })).status).toBe(400);
    expect((await adminPost("/api/admin-vault/download-links", auth.cookie, auth.csrfToken, {
      tmdbId: 603, downloadUrl: "https://provider.example/file", quality: "1080p", authorizationConfirmed: false,
    })).status).toBe(400);
    expect(upsertMovieDownloadMock).not.toHaveBeenCalled();
  });

  it("saves a valid authorized HTTPS link through the persistence abstraction", async () => {
    const authorizedLink = { tmdbId: 603, downloadUrl: "https://official-provider.example/the-matrix", quality: "4K" as const };
    upsertMovieDownloadMock.mockResolvedValue(authorizedLink);
    const auth = await login();
    const response = await adminPost("/api/admin-vault/download-links", auth.cookie, auth.csrfToken, {
      ...authorizedLink,
      authorizationConfirmed: true,
    });
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ saved: true, download: authorizedLink });
    expect(upsertMovieDownloadMock).toHaveBeenCalledWith(authorizedLink);
  });

  it("returns a mapped authorized link for a valid movie and null for an unmapped movie", async () => {
    findMovieDownloadMock.mockResolvedValueOnce({ tmdbId: 603, downloadUrl: "https://official-provider.example/the-matrix", quality: "1080p" });
    const found = await fetch(`${baseUrl}/api/download-links/603`);
    expect(found.status).toBe(200);
    expect(await found.json()).toMatchObject({ tmdbId: 603, quality: "1080p" });
    findMovieDownloadMock.mockResolvedValueOnce(null);
    const missing = await fetch(`${baseUrl}/api/download-links/604`);
    expect(await missing.json()).toBeNull();
  });
});
